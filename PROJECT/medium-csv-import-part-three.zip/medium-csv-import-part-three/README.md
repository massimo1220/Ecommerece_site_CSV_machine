# How to create a CSV file importer in React

- Part One: [Use React Dropzone to Create a Drag-n-Drop Zone for Files](https://levelup.gitconnected.com/use-react-dropzone-to-create-a-drag-n-drop-zone-for-files-f9c32dc722fc)
- Part Two: [Use Papa Parse to Parse a CSV File in a React Application](https://levelup.gitconnected.com/use-papa-parse-to-parse-a-csv-file-in-a-react-application-da570e0c346a)
- Part Three: [Use Encoding Japanese to Convert Shift JIS Characters to Unicode](https://levelup.gitconnected.com/use-encoding-japanese-to-convert-shift-jis-characters-to-unicode-8945d31f4906)
