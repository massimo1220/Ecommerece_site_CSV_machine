import './App.css';
import ExportCSV from './components/ExportCSV';

function App() {
  return (
    <div className="App">
      <h2>Export JSON Data to Excel in React</h2>
      <ExportCSV />
    </div>
  );
}

export default App;
